 <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="home.php" style="font-family: 'Satisfy',cursive">Economica</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="home.php">Home</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="g_s_t.php">GST</a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" href="tax_regulations.php">Tax Regulations</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="govt_schemes.php">Govt Schemes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact_form.php">Contact</a>
            </li>         
            
            
          </ul>
        </div>
      </div>
    </nav>